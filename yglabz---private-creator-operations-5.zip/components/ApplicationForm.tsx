
import React, { useState } from 'react';
import { FormData } from '../types';

const ApplicationForm: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    platform: '',
    audienceSize: '',
    revenue: '',
    currentMonetization: [],
    otherMonetization: '',
    bottleneck: '',
    triedMethods: '',
    whyPartner: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const submissionData = {
      ...formData,
      currentMonetization: formData.currentMonetization.join(", ") + (formData.otherMonetization ? `, Other: ${formData.otherMonetization}` : ''),
      _subject: "New Monetizing Application from Website"
    };

    try {
      const response = await fetch("https://formspree.io/f/xbdddldj", {
        method: "POST",
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(submissionData),
      });

      if (response.ok) {
        setSubmitted(true);
      } else {
        throw new Error("Failed to submit");
      }
    } catch (error) {
      alert("Something went wrong. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checkbox = e.target as HTMLInputElement;
      const updatedMonetization = checkbox.checked
        ? [...formData.currentMonetization, value]
        : formData.currentMonetization.filter(item => item !== value);
      setFormData({ ...formData, currentMonetization: updatedMonetization });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  if (submitted) {
    return (
      <div className="p-12 border border-black bg-white text-center max-w-2xl mx-auto">
        <h3 className="text-2xl font-medium mb-4">Application Received</h3>
        <p className="text-gray-500 mb-8">We will review your profile and respond within 48 hours if there is a strategic fit.</p>
        <button 
          onClick={() => setSubmitted(false)}
          className="text-xs uppercase tracking-widest font-semibold border-b border-black pb-1 hover:text-gray-400 hover:border-gray-400 transition-colors"
        >
          Submit another application
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl mx-auto space-y-10">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="flex flex-col gap-2">
          <label className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Full Name</label>
          <input 
            required
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Full Name"
            className="border-b border-gray-200 py-3 focus:outline-none focus:border-black transition-colors font-light"
          />
        </div>
        <div className="flex flex-col gap-2">
          <label className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Email Address</label>
          <input 
            required
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Email Address"
            className="border-b border-gray-200 py-3 focus:outline-none focus:border-black transition-colors font-light"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="flex flex-col gap-2">
          <label className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Primary Content Platform</label>
          <input 
            required
            name="platform"
            value={formData.platform}
            onChange={handleChange}
            placeholder="YouTube, X, etc."
            className="border-b border-gray-200 py-3 focus:outline-none focus:border-black transition-colors font-light"
          />
        </div>
        <div className="flex flex-col gap-2">
          <label className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Approximate Audience Size</label>
          <input 
            required
            name="audienceSize"
            value={formData.audienceSize}
            onChange={handleChange}
            placeholder="Size"
            className="border-b border-gray-200 py-3 focus:outline-none focus:border-black transition-colors font-light"
          />
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Current Monthly Revenue (estimate)</label>
        <input 
          required
          name="revenue"
          value={formData.revenue}
          onChange={handleChange}
          placeholder="Avg. $ / month"
          className="border-b border-gray-200 py-3 focus:outline-none focus:border-black transition-colors font-light"
        />
      </div>

      <div className="flex flex-col gap-4">
        <label className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">How are you currently monetizing your audience?</label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {['Brand deals', 'Affiliate links', 'Services (coaching / freelance)'].map(method => (
            <label key={method} className="flex items-center gap-2 font-light text-sm">
              <input 
                type="checkbox" 
                value={method} 
                onChange={handleChange}
                checked={formData.currentMonetization.includes(method)}
              />
              {method}
            </label>
          ))}
        </div>
        <div className="flex flex-col gap-2 mt-2">
          <label className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Other (please specify)</label>
          <input 
            name="otherMonetization"
            value={formData.otherMonetization}
            onChange={handleChange}
            placeholder="Other methods"
            className="border-b border-gray-200 py-2 focus:outline-none focus:border-black transition-colors font-light"
          />
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">What is the main thing holding you back from making more money right now?</label>
        <textarea 
          required
          name="bottleneck"
          value={formData.bottleneck}
          onChange={handleChange}
          rows={2}
          placeholder="Main bottleneck"
          className="border-b border-gray-200 py-3 focus:outline-none focus:border-black transition-colors font-light resize-none"
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">What methods have you already tried to monetize your audience?</label>
        <textarea 
          required
          name="triedMethods"
          value={formData.triedMethods}
          onChange={handleChange}
          rows={2}
          placeholder="Methods tried"
          className="border-b border-gray-200 py-3 focus:outline-none focus:border-black transition-colors font-light resize-none"
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Why do you think YGLABZ is the right partner for you?</label>
        <textarea 
          required
          name="whyPartner"
          value={formData.whyPartner}
          onChange={handleChange}
          rows={2}
          placeholder="Why us?"
          className="border-b border-gray-200 py-3 focus:outline-none focus:border-black transition-colors font-light resize-none"
        />
      </div>

      <div className="pt-6">
        <button 
          type="submit"
          disabled={loading}
          className={`w-full py-5 bg-black text-white text-xs font-semibold uppercase tracking-[0.3em] hover:bg-gray-800 transition-colors ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {loading ? 'Sending...' : 'Submit Application'}
        </button>
      </div>
    </form>
  );
};

export default ApplicationForm;
