
import React from 'react';

const STEPS = [
  { step: '01', title: 'Positioning', desc: 'Strategy sessions to define your brand authority and product direction.' },
  { step: '02', title: 'Product Building', desc: 'Custom creation of your digital offer, from curriculum to delivery systems.' },
  { step: '03', title: 'Launch Strategy', desc: 'Drafting the campaign to introduce your new product to your loyal audience.' },
  { step: '04', title: 'Execution', desc: 'Active management of the launch and initial sales cycle to ensure success.' }
];

const Process: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
      {STEPS.map((s, i) => (
        <div key={i} className="flex flex-col gap-6">
          <div className="text-xs font-semibold tracking-tighter text-gray-300 border-b border-gray-200 pb-4">
            PHASE {s.step}
          </div>
          <h3 className="text-lg font-medium">{s.title}</h3>
          <p className="text-sm text-gray-500 leading-relaxed font-light">{s.desc}</p>
        </div>
      ))}
    </div>
  );
};

export default Process;
