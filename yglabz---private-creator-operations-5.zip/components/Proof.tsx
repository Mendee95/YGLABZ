
import React from 'react';

const Proof: React.FC = () => {
  return (
    <div className="space-y-24">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
        <div>
          <h4 className="text-lg font-medium mb-6">The Barrier to Monetization</h4>
          <p className="text-gray-500 leading-relaxed font-light mb-6">
            Creators often rely heavily on external brand deals and low-margin affiliate links because they lack their own digital infrastructure. This leaves significant revenue on the table and limits the depth of the audience relationship.
          </p>
          <div className="p-8 bg-gray-50 border border-gray-100">
            <h5 className="text-sm font-semibold uppercase tracking-wider mb-4">Common Challenges</h5>
            <ul className="space-y-3 text-sm text-gray-600 font-light">
              <li>• Dependency on unstable brand sponsorships</li>
              <li>• Lower margins from affiliate marketing</li>
              <li>• No direct asset ownership</li>
              <li>• Missing the opportunity to solve audience problems directly</li>
            </ul>
          </div>
        </div>
        
        <div className="flex flex-col justify-center gap-12">
          <div className="border-l-4 border-black pl-8">
            <span className="text-[10px] uppercase tracking-widest text-gray-400 mb-2 block">Our Focus</span>
            <p className="text-lg text-gray-800 leading-snug">
              We bridge the gap between having an audience and having a scalable business by building the products you currently lack.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Proof;
