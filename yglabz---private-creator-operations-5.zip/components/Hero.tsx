
import React from 'react';

interface HeroProps {
  onAuditClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onAuditClick }) => {
  return (
    <section className="pt-48 pb-32 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="inline-block px-3 py-1 border border-gray-200 text-[10px] uppercase tracking-[0.3em] text-gray-400 mb-8">
          Operated by YGLABZ
        </div>
        <h1 className="text-5xl md:text-7xl font-semibold leading-[1.1] tracking-tight text-gray-900 mb-8">
          Monetizing your audience through custom products.
        </h1>
        <p className="text-xl md:text-2xl text-gray-500 leading-relaxed max-w-2xl mb-12 font-light">
          We help creators who do not have their own custom digital products build, launch, and monetize their personal brands.
        </p>
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
          <button 
            onClick={onAuditClick}
            className="w-full sm:w-auto px-10 py-5 bg-black text-white text-xs font-semibold uppercase tracking-widest hover:bg-gray-800 transition-colors"
          >
            Apply Now
          </button>
        </div>

        <div className="mt-24 pt-12 border-t border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="flex flex-col gap-1">
            <span className="text-[10px] uppercase tracking-[0.2em] text-gray-400">Our Role</span>
            <span className="text-lg font-medium">Your behind-the-scenes launch partner.</span>
          </div>
          <div className="flex items-center gap-4">
             <div className="w-12 h-[1px] bg-gray-300"></div>
             <span className="text-sm text-gray-400 italic font-light">Exclusively for creators without products</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
