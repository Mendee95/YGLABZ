
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black text-white py-24 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start gap-12">
        <div>
          <h2 className="text-2xl font-semibold tracking-tighter mb-4">YGLABZ</h2>
          <p className="text-gray-500 max-w-xs text-sm font-light leading-relaxed">
            Private Creator Operations. Engineering backend monetisation infrastructure for elite creators.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-20">
          <div>
            <h3 className="text-[10px] uppercase tracking-[0.3em] text-gray-600 mb-6">Operations</h3>
            <ul className="space-y-3 text-sm text-gray-400 font-light">
              <li>Operating Globally</li>
              <li>Remote Core Team</li>
              <li>Privacy First</li>
            </ul>
          </div>
          <div>
            <h3 className="text-[10px] uppercase tracking-[0.3em] text-gray-600 mb-6">Contact</h3>
            <a 
              href="mailto:contact@yglabz.com" 
              className="text-sm text-gray-400 font-light hover:text-white transition-colors block"
            >
              contact@yglabz.com
            </a>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto mt-24 pt-8 border-t border-gray-900 flex justify-between items-center">
        <p className="text-[10px] text-gray-700 uppercase tracking-widest">
          &copy; {new Date().getFullYear()} YGLABZ. All Rights Reserved.
        </p>
        <div className="w-1.5 h-1.5 rounded-full bg-gray-800"></div>
      </div>
    </footer>
  );
};

export default Footer;
