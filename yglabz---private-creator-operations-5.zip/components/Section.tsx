
import React from 'react';

interface SectionProps {
  title: string;
  subtitle: string;
  children: React.ReactNode;
  grayBg?: boolean;
}

const Section: React.FC<SectionProps> = ({ title, subtitle, children, grayBg }) => {
  return (
    <section className={`py-32 px-6 ${grayBg ? 'bg-gray-50' : 'bg-white'}`}>
      <div className="max-w-7xl mx-auto">
        <div className="mb-20">
          <h2 className="text-[10px] uppercase tracking-[0.3em] text-gray-400 mb-4">{title}</h2>
          <p className="text-3xl md:text-4xl font-medium tracking-tight max-w-2xl">{subtitle}</p>
        </div>
        {children}
      </div>
    </section>
  );
};

export default Section;
