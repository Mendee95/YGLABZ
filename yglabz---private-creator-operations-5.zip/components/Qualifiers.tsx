
import React from 'react';

const Qualifiers: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-20">
      <div>
        <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-green-600 mb-8 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-600"></div> Optimal Fit
        </h4>
        <ul className="space-y-6">
          <li className="flex gap-4">
            <span className="font-medium">Creators without products</span>
            <span className="text-gray-400 font-light">— You have an audience but no custom digital offer.</span>
          </li>
          <li className="flex gap-4">
            <span className="font-medium">Ready to monetize</span>
            <span className="text-gray-400 font-light">— You are interested in professional audience monetization.</span>
          </li>
          <li className="flex gap-4">
            <span className="font-medium">Active presence</span>
            <span className="text-gray-400 font-light">— You have a consistent content output on your primary platform.</span>
          </li>
          <li className="flex gap-4">
            <span className="font-medium">Partner mindset</span>
            <span className="text-gray-400 font-light">— You want a behind-the-scenes partner to handle execution.</span>
          </li>
        </ul>
      </div>

      <div>
        <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-red-600 mb-8 flex items-center gap-2">
           <div className="w-2 h-2 rounded-full bg-red-600"></div> Out Of Scope
        </h4>
        <ul className="space-y-6">
          <li className="flex gap-4">
            <span className="font-medium">Existing product owners</span>
            <span className="text-gray-400 font-light">— Creators who already have established digital product lines.</span>
          </li>
          <li className="flex gap-4">
            <span className="font-medium">Zero audience</span>
            <span className="text-gray-400 font-light">— Those looking to build an audience from scratch.</span>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Qualifiers;
