
import React from 'react';

interface NavbarProps {
  onNavClick: (id: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ onNavClick }) => {
  return (
    <nav className="fixed top-0 left-0 w-full bg-white/80 backdrop-blur-md border-b border-gray-100 z-50">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <div 
          className="text-xl font-semibold tracking-tighter cursor-pointer"
          onClick={() => onNavClick('hero')}
        >
          YGLABZ
        </div>
        
        <div className="hidden md:flex items-center space-x-10 text-sm font-medium text-gray-500 uppercase tracking-widest">
          <button onClick={() => onNavClick('what-we-do')} className="hover:text-black transition-colors">What We Do</button>
          <button onClick={() => onNavClick('how-it-works')} className="hover:text-black transition-colors">How It Works</button>
          <button onClick={() => onNavClick('proof')} className="hover:text-black transition-colors">Proof</button>
          <button 
            onClick={() => onNavClick('apply')} 
            className="px-5 py-2 border border-black text-black hover:bg-black hover:text-white transition-all duration-300"
          >
            Apply
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
