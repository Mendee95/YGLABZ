
import React from 'react';

const FEATURES = [
  {
    title: 'Personal Brand Positioning',
    desc: 'Analyzing your unique audience trust and content style to find the perfect market positioning for a custom product.'
  },
  {
    title: 'Digital Product Creation',
    desc: 'Full-cycle development of custom digital products designed to provide direct value to your existing community.'
  },
  {
    title: 'Launch Execution',
    desc: 'Managing the end-to-end launch process to ensure your product reaches your audience effectively and drives results.'
  },
  {
    title: 'Behind-the-Scenes Partner',
    desc: 'Operating as your strategic partner to handle the business logistics so you can focus on creating content.'
  }
];

const Features: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
      {FEATURES.map((f, i) => (
        <div key={i} className="group border-l border-gray-100 pl-8 py-4 hover:border-black transition-colors duration-500">
          <h3 className="text-xl font-medium mb-4">{f.title}</h3>
          <p className="text-gray-500 leading-relaxed font-light">{f.desc}</p>
        </div>
      ))}
    </div>
  );
};

export default Features;
