// Logic strictly handled in index.html for high-fidelity interaction performance.
export {};